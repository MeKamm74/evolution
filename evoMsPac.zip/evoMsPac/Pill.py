#Author: Michael Kammeyer

#Just contains location of a pill
class Pill:
	def __init__(self, x, y):
		self.x = x
		self.y = y